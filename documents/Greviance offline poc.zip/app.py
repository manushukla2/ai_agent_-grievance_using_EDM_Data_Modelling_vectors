"""
Streamlit Frontend for Grievance Data Agent
Chat interface with document upload and LLM routing display
"""

import streamlit as st
import os
import tempfile
from rag_pipeline import RAGPipeline
import config

# Page configuration
st.set_page_config(
    page_title="Grievance Data Agent",
    page_icon="🤖",
    layout="wide"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1E88E5;
        text-align: center;
        margin-bottom: 1rem;
    }
    .model-badge-simple {
        background-color: #4CAF50;
        color: white;
        padding: 4px 12px;
        border-radius: 15px;
        font-size: 0.8rem;
        font-weight: bold;
    }
    .model-badge-complex {
        background-color: #FF5722;
        color: white;
        padding: 4px 12px;
        border-radius: 15px;
        font-size: 0.8rem;
        font-weight: bold;
    }
    .stats-box {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 10px;
        margin: 0.5rem 0;
    }
    .chat-message {
        padding: 1rem;
        border-radius: 10px;
        margin: 0.5rem 0;
    }
    .user-message {
        background-color: #E3F2FD;
        border-left: 4px solid #1E88E5;
    }
    .assistant-message {
        background-color: #F5F5F5;
        border-left: 4px solid #4CAF50;
    }
</style>
""", unsafe_allow_html=True)


@st.cache_resource
def load_pipeline():
    """Load the RAG pipeline (cached to avoid reloading)"""
    with st.spinner("🔄 Loading AI models... This may take a few minutes on first run..."):
        pipeline = RAGPipeline()
    return pipeline


def display_model_badge(model_name: str, complexity: float):
    """Display a colored badge showing which model was used"""
    if "granite" in model_name.lower():
        return f'<span class="model-badge-simple">🟢 IBM Granite (Simple Query - {complexity:.0%})</span>'
    else:
        return f'<span class="model-badge-complex">🔴 Phi-3.5 (Complex Query - {complexity:.0%})</span>'


def main():
    # Header
    st.markdown('<div class="main-header">🤖 Grievance Data Agent</div>', unsafe_allow_html=True)
    st.markdown('<p style="text-align: center; color: gray;">Upload documents and ask questions - AI automatically selects the best model</p>', unsafe_allow_html=True)
    
    # Initialize pipeline
    pipeline = load_pipeline()
    
    # Initialize session state for chat history
    if "messages" not in st.session_state:
        st.session_state.messages = []
    
    # Sidebar for document management
    with st.sidebar:
        st.header("📁 Document Management")
        
        # File uploader
        uploaded_files = st.file_uploader(
            "Upload Documents",
            type=["pdf", "csv", "xlsx", "xls", "docx"],
            accept_multiple_files=True,
            help="Supported: PDF, CSV, Excel, Word"
        )
        
        if uploaded_files:
            if st.button("📥 Process & Add to Knowledge Base", type="primary"):
                progress_bar = st.progress(0)
                status_text = st.empty()
                
                for i, uploaded_file in enumerate(uploaded_files):
                    status_text.text(f"Processing: {uploaded_file.name}")
                    
                    # Save to temp file
                    with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(uploaded_file.name)[1]) as tmp_file:
                        tmp_file.write(uploaded_file.getbuffer())
                        tmp_path = tmp_file.name
                    
                    try:
                        # Ingest document
                        pipeline.ingest_document(tmp_path)
                        st.success(f"✅ Added: {uploaded_file.name}")
                    except Exception as e:
                        st.error(f"❌ Error with {uploaded_file.name}: {str(e)}")
                    finally:
                        # Clean up temp file
                        os.unlink(tmp_path)
                    
                    progress_bar.progress((i + 1) / len(uploaded_files))
                
                status_text.text("✅ All documents processed!")
                st.rerun()
        
        st.divider()
        
        # Statistics
        st.header("📊 Knowledge Base Stats")
        stats = pipeline.get_stats()
        
        col1, col2 = st.columns(2)
        with col1:
            st.metric("📄 Documents", stats["total_chunks"])
        with col2:
            st.metric("📏 Chunk Size", stats["chunk_size"])
        
        st.markdown("**Models:**")
        st.markdown(f"🟢 Simple: `{stats['simple_model'].split('/')[-1]}`")
        st.markdown(f"🔴 Complex: `{stats['complex_model'].split('/')[-1]}`")
        
        st.divider()
        
        # Clear options
        if st.button("🗑️ Clear Knowledge Base", type="secondary"):
            pipeline.clear_knowledge_base()
            st.success("Knowledge base cleared!")
            st.rerun()
        
        if st.button("🧹 Clear Chat History"):
            st.session_state.messages = []
            st.rerun()
    
    # Main chat area
    st.header("💬 Chat with your Documents")
    
    # Check if documents are loaded
    if pipeline.embedding_manager.get_collection_count() == 0:
        st.warning("⚠️ No documents in knowledge base. Please upload documents using the sidebar.")
    
    # Display chat history
    for message in st.session_state.messages:
        if message["role"] == "user":
            with st.chat_message("user"):
                st.write(message["content"])
        else:
            with st.chat_message("assistant"):
                # Show model badge
                if "model_used" in message:
                    st.markdown(
                        display_model_badge(message["model_used"], message.get("complexity", 0)),
                        unsafe_allow_html=True
                    )
                st.write(message["content"])
                
                # Show sources if available
                if message.get("show_sources") and message.get("sources"):
                    with st.expander("📚 View Sources"):
                        for i, source in enumerate(message["sources"], 1):
                            st.markdown(f"**Source {i}** (Score: {source['relevance_score']:.2f})")
                            st.text(source["content"])
                            st.divider()
    
    # Chat input
    if prompt := st.chat_input("Ask a question about your documents..."):
        # Add user message
        st.session_state.messages.append({"role": "user", "content": prompt})
        
        with st.chat_message("user"):
            st.write(prompt)
        
        # Generate response
        with st.chat_message("assistant"):
            if pipeline.embedding_manager.get_collection_count() == 0:
                response_text = "Please upload some documents first before asking questions."
                st.warning(response_text)
                st.session_state.messages.append({
                    "role": "assistant",
                    "content": response_text
                })
            else:
                with st.spinner("🤔 Thinking..."):
                    try:
                        result = pipeline.query(prompt)
                        
                        # Show model badge
                        st.markdown(
                            display_model_badge(result["model_used"], result["complexity_score"]),
                            unsafe_allow_html=True
                        )
                        
                        # Show answer
                        st.write(result["answer"])
                        
                        # Show sources
                        if result["sources"]:
                            with st.expander("📚 View Sources"):
                                for i, source in enumerate(result["sources"], 1):
                                    st.markdown(f"**Source {i}** (Score: {source['relevance_score']:.2f})")
                                    st.text(source["content"])
                                    st.divider()
                        
                        # Save to history
                        st.session_state.messages.append({
                            "role": "assistant",
                            "content": result["answer"],
                            "model_used": result["model_used"],
                            "complexity": result["complexity_score"],
                            "sources": result["sources"],
                            "show_sources": True
                        })
                        
                    except Exception as e:
                        error_msg = f"Error generating response: {str(e)}"
                        st.error(error_msg)
                        st.session_state.messages.append({
                            "role": "assistant",
                            "content": error_msg
                        })
    
    # Footer with model routing explanation
    st.divider()
    with st.expander("ℹ️ How Model Routing Works"):
        st.markdown("""
        The system automatically selects the best model based on query complexity:
        
        | Query Type | Model Used | When Used |
        |------------|------------|-----------|
        | 🟢 **Simple** | IBM Granite (2B) | Direct questions, lookups, definitions |
        | 🔴 **Complex** | Phi-3.5 Mini (3.8B) | Analysis, comparisons, multi-step reasoning |
        
        **Complexity Indicators:**
        - Keywords like "analyze", "compare", "explain why" → Complex
        - Keywords like "what is", "who is", "list" → Simple
        - Multiple questions → Complex
        - Long queries → More likely complex
        """)


if __name__ == "__main__":
    main()
