"""
Main Application Entry Point
Interactive CLI for the RAG System
"""

import os
import sys
from rag_pipeline import RAGPipeline
import config


def print_banner():
    """Print welcome banner"""
    print("\n" + "=" * 60)
    print("   GRIEVANCE DATA AGENT - RAG System")
    print("   IBM Granite (Simple) + LLaMA 3B (Complex)")
    print("=" * 60)


def print_menu():
    """Print main menu"""
    print("\n--- MENU ---")
    print("1. Add document (PDF, Excel, CSV, Word)")
    print("2. Add all documents from folder")
    print("3. Ask a question")
    print("4. View statistics")
    print("5. Clear knowledge base")
    print("6. Exit")
    print("-" * 20)


def main():
    """Main application loop"""
    print_banner()
    
    # Create documents folder if it doesn't exist
    os.makedirs(config.UPLOAD_FOLDER, exist_ok=True)
    
    # Initialize the RAG pipeline
    print("\nInitializing system (this may take a moment)...")
    
    try:
        pipeline = RAGPipeline()
    except Exception as e:
        print(f"\nError initializing pipeline: {e}")
        print("\nMake sure Ollama is running and models are downloaded:")
        print(f"  ollama pull {config.SIMPLE_MODEL}")
        print(f"  ollama pull {config.COMPLEX_MODEL}")
        sys.exit(1)
    
    while True:
        print_menu()
        choice = input("Enter choice (1-6): ").strip()
        
        if choice == "1":
            # Add single document
            file_path = input("\nEnter file path: ").strip()
            file_path = file_path.strip('"').strip("'")  # Remove quotes if any
            
            if not os.path.exists(file_path):
                print(f"Error: File not found: {file_path}")
                continue
            
            try:
                count = pipeline.ingest_document(file_path)
                print(f"\nSuccess! Total chunks in knowledge base: {count}")
            except Exception as e:
                print(f"Error: {e}")
        
        elif choice == "2":
            # Add directory
            dir_path = input(f"\nEnter directory path (default: {config.UPLOAD_FOLDER}): ").strip()
            if not dir_path:
                dir_path = config.UPLOAD_FOLDER
            
            dir_path = dir_path.strip('"').strip("'")
            
            if not os.path.exists(dir_path):
                print(f"Error: Directory not found: {dir_path}")
                continue
            
            try:
                count = pipeline.ingest_directory(dir_path)
                print(f"\nSuccess! Total chunks in knowledge base: {count}")
            except Exception as e:
                print(f"Error: {e}")
        
        elif choice == "3":
            # Ask question
            question = input("\nEnter your question: ").strip()
            
            if not question:
                print("Please enter a question.")
                continue
            
            if pipeline.embedding_manager.get_collection_count() == 0:
                print("\nWarning: No documents in knowledge base!")
                print("Add documents first using option 1 or 2.")
                continue
            
            try:
                result = pipeline.query(question)
                
                print("\n" + "=" * 60)
                print("ANSWER:")
                print("=" * 60)
                print(result["answer"])
                print("\n" + "-" * 60)
                print(f"Model used: {result['model_used']}")
                print(f"Complexity score: {result['complexity_score']:.2f}")
                print(f"Sources used: {result['num_sources']}")
                print("-" * 60)
                
                # Show sources?
                show_sources = input("\nShow source chunks? (y/n): ").strip().lower()
                if show_sources == 'y':
                    print("\n--- SOURCE CHUNKS ---")
                    for i, source in enumerate(result["sources"], 1):
                        print(f"\n[{i}] Score: {source['relevance_score']:.4f}")
                        print(f"    {source['content']}")
                
            except Exception as e:
                print(f"Error: {e}")
        
        elif choice == "4":
            # View statistics
            stats = pipeline.get_stats()
            print("\n--- STATISTICS ---")
            for key, value in stats.items():
                print(f"  {key}: {value}")
        
        elif choice == "5":
            # Clear knowledge base
            confirm = input("\nAre you sure you want to clear all documents? (yes/no): ").strip().lower()
            if confirm == "yes":
                pipeline.clear_knowledge_base()
                print("Knowledge base cleared!")
            else:
                print("Cancelled.")
        
        elif choice == "6":
            # Exit
            print("\nGoodbye!")
            break
        
        else:
            print("Invalid choice. Please enter 1-6.")


if __name__ == "__main__":
    main()
