# Configuration file for the RAG system

# Model configurations (Hugging Face model IDs)
SIMPLE_MODEL = "ibm-granite/granite-3.0-2b-instruct"  # IBM Granite for simple queries
COMPLEX_MODEL = "microsoft/Phi-3.5-mini-instruct"  # Phi-3.5 Mini (3.8B) for complex queries - open model

# Embedding model
EMBEDDING_MODEL = "all-MiniLM-L6-v2"  # Sentence transformer for embeddings

# ChromaDB settings
CHROMA_PERSIST_DIR = "./chroma_db"
COLLECTION_NAME = "documents"

# Chunking settings
CHUNK_SIZE = 1000  # characters per chunk
CHUNK_OVERLAP = 200  # overlap between chunks

# Document upload folder
UPLOAD_FOLDER = "./documents"

# Query complexity threshold (for routing)
COMPLEXITY_THRESHOLD = 0.5
