"""
Embedding and Vector Store Module
Handles text chunking, embedding, and vector storage
Uses Sentence Transformers and a simple JSON-based vector store
"""

import os
import json
import numpy as np
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass, asdict
from sentence_transformers import SentenceTransformer
import config


@dataclass
class Document:
    """Simple document class to hold content and metadata"""
    page_content: str
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}


class TextSplitter:
    """
    Splits text into chunks with overlap
    
    WHAT IS CHUNKING?
    -----------------
    Large documents are split into smaller pieces called "chunks".
    Why? 
    1. LLMs have token limits
    2. Smaller chunks = more precise retrieval
    3. Better matching for specific queries
    
    Example: A 50-page PDF is split into 100 chunks of 1000 chars each
    """
    
    def __init__(self, chunk_size: int = 1000, chunk_overlap: int = 200):
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.separators = ["\n\n", "\n", ". ", " ", ""]
    
    def split_text(self, text: str) -> List[str]:
        """Split text into chunks"""
        chunks = []
        
        # Try to split by separators in order of preference
        for separator in self.separators:
            if separator in text:
                parts = text.split(separator)
                current_chunk = ""
                
                for part in parts:
                    if len(current_chunk) + len(part) + len(separator) <= self.chunk_size:
                        current_chunk += part + separator
                    else:
                        if current_chunk:
                            chunks.append(current_chunk.strip())
                        current_chunk = part + separator
                
                if current_chunk:
                    chunks.append(current_chunk.strip())
                break
        
        # If no separators found, split by character count
        if not chunks:
            for i in range(0, len(text), self.chunk_size - self.chunk_overlap):
                chunks.append(text[i:i + self.chunk_size])
        
        return [c for c in chunks if c.strip()]
    
    def split_documents(self, documents: List[Document]) -> List[Document]:
        """Split documents into chunks, preserving metadata"""
        chunked_docs = []
        
        for doc in documents:
            text_chunks = self.split_text(doc.page_content)
            
            for i, chunk in enumerate(text_chunks):
                new_metadata = doc.metadata.copy() if doc.metadata else {}
                new_metadata['chunk_index'] = i
                chunked_docs.append(Document(page_content=chunk, metadata=new_metadata))
        
        return chunked_docs


class SimpleVectorStore:
    """
    A simple file-based vector database using NumPy
    
    This stores:
    - embeddings: numpy array of vectors
    - documents: list of text content
    - metadatas: list of metadata dicts
    
    Uses cosine similarity for search
    """
    
    def __init__(self, persist_dir: str, collection_name: str):
        self.persist_dir = persist_dir
        self.collection_name = collection_name
        self.data_file = os.path.join(persist_dir, f"{collection_name}_data.json")
        self.embeddings_file = os.path.join(persist_dir, f"{collection_name}_embeddings.npy")
        
        os.makedirs(persist_dir, exist_ok=True)
        
        # Load existing data or initialize empty
        self.documents = []
        self.metadatas = []
        self.embeddings = None
        
        self._load()
    
    def _load(self):
        """Load data from disk"""
        if os.path.exists(self.data_file):
            with open(self.data_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                self.documents = data.get('documents', [])
                self.metadatas = data.get('metadatas', [])
        
        if os.path.exists(self.embeddings_file):
            self.embeddings = np.load(self.embeddings_file)
    
    def _save(self):
        """Save data to disk"""
        with open(self.data_file, 'w', encoding='utf-8') as f:
            json.dump({
                'documents': self.documents,
                'metadatas': self.metadatas
            }, f, ensure_ascii=False, indent=2)
        
        if self.embeddings is not None:
            np.save(self.embeddings_file, self.embeddings)
    
    def add(self, documents: List[str], embeddings: List[List[float]], metadatas: List[Dict] = None):
        """Add documents with their embeddings"""
        new_embeddings = np.array(embeddings)
        
        if self.embeddings is None:
            self.embeddings = new_embeddings
        else:
            self.embeddings = np.vstack([self.embeddings, new_embeddings])
        
        self.documents.extend(documents)
        
        if metadatas:
            self.metadatas.extend(metadatas)
        else:
            self.metadatas.extend([{} for _ in documents])
        
        self._save()
    
    def search(self, query_embedding: List[float], k: int = 4) -> List[Tuple[str, Dict, float]]:
        """
        Search for similar documents using cosine similarity
        
        Returns: List of (document_text, metadata, similarity_score)
        """
        if self.embeddings is None or len(self.documents) == 0:
            return []
        
        query_vec = np.array(query_embedding)
        
        # Compute cosine similarity
        # cos_sim = (A . B) / (||A|| * ||B||)
        dot_products = np.dot(self.embeddings, query_vec)
        query_norm = np.linalg.norm(query_vec)
        doc_norms = np.linalg.norm(self.embeddings, axis=1)
        
        similarities = dot_products / (doc_norms * query_norm + 1e-10)
        
        # Get top k indices
        top_k_indices = np.argsort(similarities)[::-1][:k]
        
        results = []
        for idx in top_k_indices:
            results.append((
                self.documents[idx],
                self.metadatas[idx],
                float(similarities[idx])
            ))
        
        return results
    
    def count(self) -> int:
        """Return number of documents"""
        return len(self.documents)
    
    def clear(self):
        """Clear all data"""
        self.documents = []
        self.metadatas = []
        self.embeddings = None
        
        if os.path.exists(self.data_file):
            os.remove(self.data_file)
        if os.path.exists(self.embeddings_file):
            os.remove(self.embeddings_file)


class EmbeddingManager:
    """
    Manages document embedding and vector store
    
    WHAT IS EMBEDDING?
    ------------------
    Embedding is converting text into numerical vectors (arrays of numbers).
    These vectors capture the semantic meaning of text.
    Similar texts will have similar vectors (close in vector space).
    
    Example: "dog" and "puppy" will have similar embeddings
             "dog" and "airplane" will have different embeddings
    """
    
    def __init__(self):
        # Initialize the embedding model
        print(f"Loading embedding model: {config.EMBEDDING_MODEL}")
        self.embedding_model = SentenceTransformer(config.EMBEDDING_MODEL)
        print("✓ Embedding model loaded!")
        
        # Initialize text splitter for chunking
        self.text_splitter = TextSplitter(
            chunk_size=config.CHUNK_SIZE,
            chunk_overlap=config.CHUNK_OVERLAP
        )
        
        # Initialize vector store
        self.vector_store = SimpleVectorStore(
            persist_dir=config.CHROMA_PERSIST_DIR,
            collection_name=config.COLLECTION_NAME
        )
        print(f"✓ Vector Store initialized! Collection: {config.COLLECTION_NAME}")
        print(f"  Documents in store: {self.vector_store.count()}")
    
    def _embed_texts(self, texts: List[str]) -> List[List[float]]:
        """Create embeddings for a list of texts"""
        embeddings = self.embedding_model.encode(texts, show_progress_bar=True)
        return embeddings.tolist()
    
    def chunk_documents(self, documents: List[Document]) -> List[Document]:
        """Split documents into smaller chunks"""
        chunks = self.text_splitter.split_documents(documents)
        print(f"Split {len(documents)} document(s) into {len(chunks)} chunks")
        print(f"Chunk size: {config.CHUNK_SIZE} chars, Overlap: {config.CHUNK_OVERLAP} chars")
        return chunks
    
    def add_documents(self, documents: List[Document]) -> None:
        """
        Chunk, embed, and store documents in vector store
        
        Process:
        1. Split documents into chunks
        2. Create embeddings for each chunk
        3. Store embeddings + text in vector store
        """
        # Chunk the documents
        chunks = self.chunk_documents(documents)
        
        if not chunks:
            print("No chunks to add!")
            return
        
        # Prepare data
        texts = [chunk.page_content for chunk in chunks]
        metadatas = [chunk.metadata for chunk in chunks]
        
        # Create embeddings
        print(f"Creating embeddings for {len(texts)} chunks...")
        embeddings = self._embed_texts(texts)
        
        # Add to vector store
        print(f"Storing {len(chunks)} chunks in vector store...")
        self.vector_store.add(texts, embeddings, metadatas)
        print("✓ Documents added successfully!")
    
    def similarity_search(self, query: str, k: int = 4) -> List[Document]:
        """
        Search for similar documents based on query
        
        Process:
        1. Convert query to embedding
        2. Find k most similar chunks
        3. Return matching documents
        """
        # Create query embedding
        query_embedding = self.embedding_model.encode([query])[0].tolist()
        
        # Search vector store
        results = self.vector_store.search(query_embedding, k=k)
        
        # Convert to Document objects
        documents = []
        for doc_text, metadata, score in results:
            documents.append(Document(page_content=doc_text, metadata=metadata))
        
        return documents
    
    def similarity_search_with_score(self, query: str, k: int = 4) -> List[Tuple[Document, float]]:
        """
        Search with relevance scores
        
        Returns list of (document, score) tuples
        Higher score = more similar (cosine similarity)
        """
        # Create query embedding
        query_embedding = self.embedding_model.encode([query])[0].tolist()
        
        # Search vector store
        results = self.vector_store.search(query_embedding, k=k)
        
        # Convert to (Document, score) tuples
        doc_score_pairs = []
        for doc_text, metadata, score in results:
            doc = Document(page_content=doc_text, metadata=metadata)
            doc_score_pairs.append((doc, score))
        
        return doc_score_pairs
    
    def get_collection_count(self) -> int:
        """Get number of documents in the collection"""
        return self.vector_store.count()
    
    def clear_collection(self) -> None:
        """Clear all documents from the collection"""
        self.vector_store.clear()
        print("✓ Collection cleared!")


if __name__ == "__main__":
    # Test the embedding manager
    manager = EmbeddingManager()
    print(f"\nDocuments in collection: {manager.get_collection_count()}")

