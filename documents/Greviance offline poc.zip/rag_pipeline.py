"""
RAG Pipeline Module
Main pipeline that integrates all components
"""

from typing import List, Optional

from document_loader import DocumentLoader, Document
from embedding_manager import EmbeddingManager
from query_router import QueryRouter
import config


class RAGPipeline:
    """
    Complete RAG (Retrieval Augmented Generation) Pipeline
    
    FLOW:
    1. Load documents (PDF, Excel, CSV, Word)
    2. Chunk documents into smaller pieces
    3. Create embeddings and store in ChromaDB
    4. User asks question
    5. Retrieve relevant chunks from ChromaDB
    6. Route to appropriate LLM based on complexity
    7. Generate answer using retrieved context
    """
    
    # Prompt template for RAG
    PROMPT_TEMPLATE = """You are a helpful assistant. Use the following context to answer the question. 
If the answer is not in the context, say "I don't have enough information to answer this question."

Context:
{context}

Question: {question}

Answer: """
    
    def __init__(self):
        print("=" * 50)
        print("Initializing RAG Pipeline...")
        print("=" * 50)
        
        # Initialize components
        self.document_loader = DocumentLoader()
        self.embedding_manager = EmbeddingManager()
        self.query_router = QueryRouter()
        
        print("=" * 50)
        print("RAG Pipeline initialized successfully!")
        print(f"Documents in vector store: {self.embedding_manager.get_collection_count()}")
        print("=" * 50)
    
    def ingest_document(self, file_path: str) -> int:
        """
        Ingest a single document into the vector store
        
        Args:
            file_path: Path to the document
            
        Returns:
            Number of chunks created
        """
        print(f"\n--- Ingesting document: {file_path} ---")
        
        # Load document
        documents = self.document_loader.load_document(file_path)
        
        # Add to vector store (chunking and embedding happens inside)
        self.embedding_manager.add_documents(documents)
        
        return self.embedding_manager.get_collection_count()
    
    def ingest_directory(self, directory_path: str) -> int:
        """
        Ingest all documents from a directory
        
        Args:
            directory_path: Path to directory containing documents
            
        Returns:
            Number of chunks in vector store
        """
        print(f"\n--- Ingesting directory: {directory_path} ---")
        
        # Load all documents
        documents = self.document_loader.load_directory(directory_path)
        
        # Add to vector store
        if documents:
            self.embedding_manager.add_documents(documents)
        
        return self.embedding_manager.get_collection_count()
    
    def query(self, question: str, k: int = 4) -> dict:
        """
        Query the RAG system
        
        Args:
            question: User's question
            k: Number of relevant chunks to retrieve
            
        Returns:
            Dictionary with answer, model used, sources, etc.
        """
        print(f"\n{'=' * 50}")
        print(f"Question: {question}")
        print("=" * 50)
        
        # Step 1: Retrieve relevant documents
        print("\n[1] Retrieving relevant documents from ChromaDB...")
        relevant_docs = self.embedding_manager.similarity_search_with_score(question, k=k)
        
        if not relevant_docs:
            return {
                "question": question,
                "answer": "No relevant documents found in the knowledge base.",
                "model_used": None,
                "sources": [],
                "complexity_score": 0
            }
        
        # Step 2: Build context from retrieved documents
        print(f"[2] Found {len(relevant_docs)} relevant chunks")
        context_parts = []
        sources = []
        
        for doc, score in relevant_docs:
            context_parts.append(doc.page_content)
            sources.append({
                "content": doc.page_content[:200] + "..." if len(doc.page_content) > 200 else doc.page_content,
                "metadata": doc.metadata,
                "relevance_score": float(score)
            })
            print(f"   - Score: {score:.4f} | Preview: {doc.page_content[:50]}...")
        
        context = "\n\n---\n\n".join(context_parts)
        
        # Step 3: Route to appropriate model
        print("\n[3] Routing query to appropriate model...")
        model_name, complexity, use_complex = self.query_router.route_query(question)
        
        # Step 4: Generate answer
        print(f"\n[4] Generating answer using {model_name}...")
        
        # Create the prompt
        prompt = self.PROMPT_TEMPLATE.format(context=context, question=question)
        
        # Get response from LLM using the router
        answer = self.query_router.generate_response(prompt, use_complex=use_complex)
        
        print(f"\n{'=' * 50}")
        print("Answer generated successfully!")
        print("=" * 50)
        
        return {
            "question": question,
            "answer": answer,
            "model_used": model_name,
            "complexity_score": complexity,
            "sources": sources,
            "num_sources": len(sources)
        }
    
    def get_stats(self) -> dict:
        """Get statistics about the vector store"""
        return {
            "total_chunks": self.embedding_manager.get_collection_count(),
            "simple_model": config.SIMPLE_MODEL,
            "complex_model": config.COMPLEX_MODEL,
            "chunk_size": config.CHUNK_SIZE,
            "chunk_overlap": config.CHUNK_OVERLAP
        }
    
    def clear_knowledge_base(self) -> None:
        """Clear all documents from the vector store"""
        self.embedding_manager.clear_collection()
        print("Knowledge base cleared!")


if __name__ == "__main__":
    # Test the pipeline
    pipeline = RAGPipeline()
    
    print("\nPipeline Stats:")
    stats = pipeline.get_stats()
    for key, value in stats.items():
        print(f"  {key}: {value}")
