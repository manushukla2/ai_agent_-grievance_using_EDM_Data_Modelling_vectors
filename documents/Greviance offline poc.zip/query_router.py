"""
Query Router Module
Routes queries to appropriate LLM based on complexity
Uses Hugging Face Transformers to run models locally
"""

import torch
from typing import Tuple
from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline
import config


class QueryRouter:
    """
    Determines query complexity and routes to appropriate model
    
    ROUTING LOGIC:
    -------------
    Simple queries -> IBM Granite (250M) - faster, less compute
    Complex queries -> LLaMA 3B - better reasoning
    
    COMPLEXITY INDICATORS:
    - Simple: Direct questions, keyword lookups, yes/no questions
    - Complex: Multi-step reasoning, comparisons, analysis, summarization
    """
    
    # Keywords indicating complex queries
    COMPLEX_KEYWORDS = [
        'analyze', 'compare', 'contrast', 'explain why', 'summarize',
        'what are the implications', 'how does this affect', 'evaluate',
        'critically', 'in-depth', 'comprehensive', 'relationship between',
        'cause and effect', 'pros and cons', 'advantages and disadvantages',
        'step by step', 'detailed', 'elaborate', 'multiple', 'all the',
        'difference between', 'similarities', 'impact', 'consequences'
    ]
    
    # Keywords indicating simple queries
    SIMPLE_KEYWORDS = [
        'what is', 'who is', 'when', 'where', 'define', 'list',
        'name', 'find', 'show', 'get', 'tell me', 'what are'
    ]
    
    def __init__(self):
        print("Initializing Query Router...")
        
        # Determine device
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        print(f"Using device: {self.device}")
        
        # Initialize both LLM models from Hugging Face
        print(f"\nLoading simple model: {config.SIMPLE_MODEL}")
        print("(This will download the model on first run...)")
        
        self.simple_tokenizer = AutoTokenizer.from_pretrained(config.SIMPLE_MODEL)
        self.simple_model = AutoModelForCausalLM.from_pretrained(
            config.SIMPLE_MODEL,
            torch_dtype=torch.float16 if self.device == "cuda" else torch.float32,
            device_map="auto" if self.device == "cuda" else None,
            low_cpu_mem_usage=True
        )
        if self.device == "cpu":
            self.simple_model = self.simple_model.to(self.device)
        
        self.simple_pipe = pipeline(
            "text-generation",
            model=self.simple_model,
            tokenizer=self.simple_tokenizer,
            max_new_tokens=512,
            do_sample=True,
            temperature=0.7,
        )
        print(f"✓ Simple model loaded!")
        
        print(f"\nLoading complex model: {config.COMPLEX_MODEL}")
        print("(This will download the model on first run...)")
        
        self.complex_tokenizer = AutoTokenizer.from_pretrained(config.COMPLEX_MODEL)
        self.complex_model = AutoModelForCausalLM.from_pretrained(
            config.COMPLEX_MODEL,
            torch_dtype=torch.float16 if self.device == "cuda" else torch.float32,
            device_map="auto" if self.device == "cuda" else None,
            low_cpu_mem_usage=True
        )
        if self.device == "cpu":
            self.complex_model = self.complex_model.to(self.device)
        
        self.complex_pipe = pipeline(
            "text-generation",
            model=self.complex_model,
            tokenizer=self.complex_tokenizer,
            max_new_tokens=1024,
            do_sample=True,
            temperature=0.7,
        )
        print(f"✓ Complex model loaded!")
        
        print("\nQuery Router initialized!")
    
    def calculate_complexity(self, query: str) -> Tuple[float, str]:
        """
        Calculate query complexity score
        
        Returns:
            Tuple of (complexity_score, reasoning)
            Score: 0.0 (simple) to 1.0 (complex)
        """
        query_lower = query.lower()
        score = 0.0
        reasons = []
        
        # Check for complex keywords
        complex_matches = sum(1 for kw in self.COMPLEX_KEYWORDS if kw in query_lower)
        if complex_matches > 0:
            score += min(complex_matches * 0.2, 0.6)
            reasons.append(f"Contains {complex_matches} complex keyword(s)")
        
        # Check query length (longer queries tend to be more complex)
        word_count = len(query.split())
        if word_count > 20:
            score += 0.2
            reasons.append("Long query")
        elif word_count > 10:
            score += 0.1
            reasons.append("Medium length query")
        
        # Check for multiple questions
        question_marks = query.count('?')
        if question_marks > 1:
            score += 0.2
            reasons.append(f"Multiple questions ({question_marks})")
        
        # Check for simple keywords at start
        for kw in self.SIMPLE_KEYWORDS:
            if query_lower.startswith(kw):
                score -= 0.2
                reasons.append(f"Starts with simple keyword '{kw}'")
                break
        
        # Normalize score between 0 and 1
        score = max(0.0, min(1.0, score))
        
        reasoning = "; ".join(reasons) if reasons else "Default complexity"
        return score, reasoning
    
    def generate_response(self, prompt: str, use_complex: bool = False) -> str:
        """Generate response using the appropriate model"""
        if use_complex:
            response = self.complex_pipe(prompt)
        else:
            response = self.simple_pipe(prompt)
        
        # Extract generated text
        generated_text = response[0]['generated_text']
        
        # Remove the input prompt from output
        if generated_text.startswith(prompt):
            generated_text = generated_text[len(prompt):].strip()
        
        return generated_text
    
    def route_query(self, query: str) -> Tuple[str, float, bool]:
        """
        Route query to appropriate model
        
        Returns:
            Tuple of (model_name, complexity_score, use_complex)
        """
        complexity, reasoning = self.calculate_complexity(query)
        
        use_complex = complexity >= config.COMPLEXITY_THRESHOLD
        
        if use_complex:
            model_name = config.COMPLEX_MODEL
            print(f"[ROUTER] Complex query (score: {complexity:.2f}) -> {model_name}")
        else:
            model_name = config.SIMPLE_MODEL
            print(f"[ROUTER] Simple query (score: {complexity:.2f}) -> {model_name}")
        
        print(f"[ROUTER] Reasoning: {reasoning}")
        
        return model_name, complexity, use_complex
    
    def get_simple_pipeline(self):
        """Get the simple model pipeline"""
        return self.simple_pipe
    
    def get_complex_pipeline(self):
        """Get the complex model pipeline"""
        return self.complex_pipe


if __name__ == "__main__":
    # Test the router
    router = QueryRouter()
    
    test_queries = [
        "What is machine learning?",
        "Compare and contrast supervised and unsupervised learning, explaining the pros and cons of each approach",
        "Who is the CEO?",
        "Analyze the impact of AI on healthcare and explain the long-term implications"
    ]
    
    for query in test_queries:
        print(f"\nQuery: {query}")
        model, score, _ = router.route_query(query)
        print(f"Routed to: {model} (complexity: {score:.2f})")
