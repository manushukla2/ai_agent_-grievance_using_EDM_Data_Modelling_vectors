"""
Document Loader Module
Handles loading of PDF, Excel, CSV, and Word documents
Uses native libraries without LangChain
"""

import os
from typing import List, Dict, Any
from dataclasses import dataclass
import pandas as pd
from pypdf import PdfReader
from docx import Document as DocxDocument


@dataclass
class Document:
    """Simple document class to hold content and metadata"""
    page_content: str
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}


class DocumentLoader:
    """Loads documents from various file formats"""
    
    SUPPORTED_EXTENSIONS = {
        '.pdf': 'pdf',
        '.docx': 'word',
        '.doc': 'word',
        '.csv': 'csv',
        '.xlsx': 'excel',
        '.xls': 'excel'
    }
    
    def __init__(self):
        pass
    
    def load_pdf(self, file_path: str) -> List[Document]:
        """Load PDF document"""
        documents = []
        reader = PdfReader(file_path)
        
        for i, page in enumerate(reader.pages):
            text = page.extract_text()
            if text.strip():
                documents.append(Document(
                    page_content=text,
                    metadata={"source": file_path, "page": i + 1, "type": "pdf"}
                ))
        
        return documents
    
    def load_word(self, file_path: str) -> List[Document]:
        """Load Word document (.docx)"""
        doc = DocxDocument(file_path)
        
        # Extract all paragraphs
        full_text = []
        for para in doc.paragraphs:
            if para.text.strip():
                full_text.append(para.text)
        
        # Also extract text from tables
        for table in doc.tables:
            for row in table.rows:
                row_text = [cell.text for cell in row.cells if cell.text.strip()]
                if row_text:
                    full_text.append(" | ".join(row_text))
        
        content = "\n".join(full_text)
        
        if content.strip():
            return [Document(
                page_content=content,
                metadata={"source": file_path, "type": "word"}
            )]
        return []
    
    def load_csv(self, file_path: str) -> List[Document]:
        """Load CSV file"""
        documents = []
        df = pd.read_csv(file_path)
        
        # Convert each row to a document
        for idx, row in df.iterrows():
            # Create a text representation of the row
            row_text = " | ".join([f"{col}: {val}" for col, val in row.items() if pd.notna(val)])
            if row_text.strip():
                documents.append(Document(
                    page_content=row_text,
                    metadata={"source": file_path, "row": idx + 1, "type": "csv"}
                ))
        
        return documents
    
    def load_excel(self, file_path: str) -> List[Document]:
        """Load Excel file (.xlsx, .xls)"""
        documents = []
        
        # Read all sheets
        excel_file = pd.ExcelFile(file_path)
        
        for sheet_name in excel_file.sheet_names:
            df = pd.read_excel(file_path, sheet_name=sheet_name)
            
            # Convert each row to a document
            for idx, row in df.iterrows():
                row_text = " | ".join([f"{col}: {val}" for col, val in row.items() if pd.notna(val)])
                if row_text.strip():
                    documents.append(Document(
                        page_content=row_text,
                        metadata={"source": file_path, "sheet": sheet_name, "row": idx + 1, "type": "excel"}
                    ))
        
        return documents
    
    def load_document(self, file_path: str) -> List[Document]:
        """Load document based on file extension"""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
        
        _, ext = os.path.splitext(file_path)
        ext = ext.lower()
        
        if ext not in self.SUPPORTED_EXTENSIONS:
            raise ValueError(f"Unsupported file type: {ext}. Supported: {list(self.SUPPORTED_EXTENSIONS.keys())}")
        
        file_type = self.SUPPORTED_EXTENSIONS[ext]
        
        loaders = {
            'pdf': self.load_pdf,
            'word': self.load_word,
            'csv': self.load_csv,
            'excel': self.load_excel
        }
        
        print(f"Loading {file_type} file: {file_path}")
        documents = loaders[file_type](file_path)
        print(f"Loaded {len(documents)} document(s) from {file_path}")
        
        return documents
    
    def load_directory(self, directory_path: str) -> List[Document]:
        """Load all supported documents from a directory"""
        if not os.path.exists(directory_path):
            raise FileNotFoundError(f"Directory not found: {directory_path}")
        
        all_documents = []
        
        for filename in os.listdir(directory_path):
            file_path = os.path.join(directory_path, filename)
            
            if os.path.isfile(file_path):
                _, ext = os.path.splitext(filename)
                
                if ext.lower() in self.SUPPORTED_EXTENSIONS:
                    try:
                        docs = self.load_document(file_path)
                        all_documents.extend(docs)
                    except Exception as e:
                        print(f"Error loading {filename}: {e}")
        
        print(f"\nTotal documents loaded: {len(all_documents)}")
        return all_documents


if __name__ == "__main__":
    # Test the loader
    loader = DocumentLoader()
    print("Document Loader initialized successfully!")
    print(f"Supported formats: {list(loader.SUPPORTED_EXTENSIONS.keys())}")
